#!/usr/bin/python
##!/data/apps/python/2.7.2/bin/python



import sys
import subprocess
import datetime
from collections import defaultdict
import os
from subprocess import Popen
import multiprocessing as mp

countProcess =0
QPs = ["22"]
HOME = os.environ["HOME"]
PIN_BASE = HOME + '/mem_approx/pin-memapprox'
videos = [["BasketballDrive_1920x1080_50", "1080p", "50","1920x1080"]]
#taskset -c {8}



mkdir = '''mkdir {0}_qp{3}_{1}_{2}'''
cd = '''{0}_qp{3}_{1}_{2}/'''
cmd = ''' {0}/pin \
-t {0:}/source/tools/ManualExamples/obj-intel64/memapprox.so   \
  -- {0:}/examples/x265_2.5/build/linux/x265 \
--input-res {1} \
--fps {2} \
--preset 5 \
-f 2 \
--qp {9} \
--input /data/videos/{4:}/{5}.yuv \
--frame-threads 1 --no-wpp --no-pmode  --no-pme --lookahead-slices 0 \
-o {0:}/examples/x265_2.5/outputs/videos/{5}_qp{9}_{6}_{7:}.265 \
--wber-me {6:} \
--rber-me {7:} \
--psnr  \
--csv-log-level 2 \
--csv {0:}/examples/x265_2.5/outputs/csv/{5}_qp{9}_{6}_{7:}.csv \
--tune psnr \
--tune ssim'''
BERS = [ "1E-7", "1E-6", "1E-5", "1E-4", "1E-3" ]
WERS = [ "1E-7", "1E-6", "1E-5", "1E-4", "1E-3" ]
#tp = ThreadPool(20)


#BERS = [ "1E-7", "1E-6"	]
#WERS = [ "1E-7", "1E-6"	]


def work(command, CD, simout_f):
	print "\nCHAMOU\n"
	subprocess.Popen(command, cwd=CD, stdout=simout_f, stderr=simout_f, shell=True)

 



def run_pin_experiments():
	p = mp.Pool(processes=20)
	os.chdir("outputs/") #mudar diretorio para memapprox.log
	for video in videos:
		for ber in BERS:
		    for wer in WERS:
			for qp in QPs:
			    CMDd = cmd.format(PIN_BASE, video[3], video[2], HOME, video[1], video[0], ber,wer, countProcess, qp)
			    print CMDd + "\n\n"
			    simout = '{0}/examples/x265_2.5/outputs/logs/{1}_qp{4}_{2}_{3}.log'.format(PIN_BASE, video[0], ber, wer, qp)
			    simout_f = open(simout, "w")
			    #subprocess.call(CMDd, stdout=simout_f, stderr=simout_f, shell=True)
			    #processes = [Popen(CMDd, stdout=simout_f, stderr=simout_f, shell=True)]
			    MK = mkdir.format(video[0], ber, wer, qp)
			    CD = cd.format(video[0], ber, wer, qp)
			    #print MK + "\n\n"
			    subprocess.call(MK, shell=True)
			    p.apply_async(work, (CMDd,CD, simout_f,))
			    #temp = pool.apply_async(work, (CMDd,CD, simout_f,))
			    #os.chdir("../")

	p.close()
	p.join()

if __name__ == "__main__":
 
  run_pin_experiments()

